package com.example.klocalservice.model.base;


import java.io.Serializable;


/**
 * 数据对象基类
 */
public class BaseModel implements Serializable {

}