package com.example.klocalservice.manager;



/**
 * 页面跳转管理
 */
public class ActivityGoManager {
}