package com.example.klocalservice.mvp.contract;

public interface MainContract {
    interface Presenter extends BaseContract.Presenter {
    }

    interface View extends BaseContract.View {
    }
}