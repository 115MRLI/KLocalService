package com.example.klocalservice.mvp.contract;

/**
 * 协议基类
 * Created by wuxubaiyang on 16/5/5.
 */
public interface BaseContract {

    interface Presenter {
    }

    interface View {
    }
}